﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 복사해보기
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) //아이템추가
        {
            cbMeat.Items.Add("돼지고기");
            cbMeat.Items.Add("소고기");
            cbMeat.Items.Add("양고기");
        }

        private void metroButton1_Click(object sender, EventArgs e) //닫기
        {
            Application.Exit();
        }

        private void txtOrderNum_Click(object sender, EventArgs e)
        {
        }
        private void cbMeat_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void metroButton1_Click_1(object sender, EventArgs e) //주문종류 및 갯수 확인
        {
            int numPork = 100; //돼지
            int numBeef = 100; //소
            int numSheep = 100; //양

            String txt = cbMeat.SelectedItem as String;
            int ODNum = int.Parse(txtOrderNum.Text); //주문수량

            if (cbMeat.SelectedIndex == 0)
            {
                int Result = numPork - ODNum;

                if (Result >= 0)
                { MessageBox.Show($"{txt}(을)를 {ODNum}개 주문합니다.", "주문하기", MessageBoxButtons.YesNo); }
                else
                { MessageBox.Show($"{txt}재고량이 모자랍니다..", "재고량 부족", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            }

            else if (cbMeat.SelectedIndex == 1)
            {
                int Result = numBeef - ODNum;

                if (Result >= 0)
                { MessageBox.Show($"{txt}(을)를 {ODNum}개 주문합니다.", "주문하기", MessageBoxButtons.YesNo); }
                else
                { MessageBox.Show($"{txt}재고량이 모자랍니다..", "재고량 부족", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            }

            else if (cbMeat.SelectedIndex == 2)
            {
                int Result = numSheep - ODNum;

                if (Result >= 0)
                { MessageBox.Show($"{txt}(을)를 {ODNum}개 주문합니다.", "주문하기", MessageBoxButtons.YesNo); }
                else
                { MessageBox.Show($"{txt}재고량이 모자랍니다..", "재고량 부족", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            }

        }
    }
}
