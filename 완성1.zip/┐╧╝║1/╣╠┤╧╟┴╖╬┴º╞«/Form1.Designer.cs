﻿
namespace 복사해보기
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lambLips = new MetroFramework.Controls.MetroProgressBar();
            this.lambBack = new MetroFramework.Controls.MetroProgressBar();
            this.lambBehind = new MetroFramework.Controls.MetroProgressBar();
            this.lambFront = new MetroFramework.Controls.MetroProgressBar();
            this.beefLips = new MetroFramework.Controls.MetroProgressBar();
            this.beefBack = new MetroFramework.Controls.MetroProgressBar();
            this.beefBehind = new MetroFramework.Controls.MetroProgressBar();
            this.beefFront = new MetroFramework.Controls.MetroProgressBar();
            this.porkLips = new MetroFramework.Controls.MetroProgressBar();
            this.porkBack = new MetroFramework.Controls.MetroProgressBar();
            this.porkBehind = new MetroFramework.Controls.MetroProgressBar();
            this.porkFront = new MetroFramework.Controls.MetroProgressBar();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.order = new MetroFramework.Controls.MetroButton();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.add = new MetroFramework.Controls.MetroButton();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip4 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip5 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip6 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip7 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip8 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip9 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip10 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip11 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip12 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.metroLabel7);
            this.groupBox1.Controls.Add(this.metroLabel6);
            this.groupBox1.Controls.Add(this.metroLabel5);
            this.groupBox1.Controls.Add(this.metroLabel4);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.lambLips);
            this.groupBox1.Controls.Add(this.lambBack);
            this.groupBox1.Controls.Add(this.lambBehind);
            this.groupBox1.Controls.Add(this.lambFront);
            this.groupBox1.Controls.Add(this.beefLips);
            this.groupBox1.Controls.Add(this.beefBack);
            this.groupBox1.Controls.Add(this.beefBehind);
            this.groupBox1.Controls.Add(this.beefFront);
            this.groupBox1.Controls.Add(this.porkLips);
            this.groupBox1.Controls.Add(this.porkBack);
            this.groupBox1.Controls.Add(this.porkBehind);
            this.groupBox1.Controls.Add(this.porkFront);
            this.groupBox1.Controls.Add(this.metroLabel3);
            this.groupBox1.Controls.Add(this.metroLabel2);
            this.groupBox1.Controls.Add(this.metroLabel1);
            this.groupBox1.Controls.Add(this.order);
            this.groupBox1.Controls.Add(this.metroButton3);
            this.groupBox1.Controls.Add(this.add);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(40, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(832, 504);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "재고량";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(760, 208);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(39, 20);
            this.metroLabel7.TabIndex = 26;
            this.metroLabel7.Text = "갈비";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(592, 208);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(39, 20);
            this.metroLabel6.TabIndex = 25;
            this.metroLabel6.Text = "등심";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(416, 208);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(54, 20);
            this.metroLabel5.TabIndex = 24;
            this.metroLabel5.Text = "뒷다리";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(240, 208);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(54, 20);
            this.metroLabel4.TabIndex = 23;
            this.metroLabel4.Text = "앞다리";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(648, 152);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(72, 85);
            this.pictureBox4.TabIndex = 22;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(480, 152);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(72, 85);
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(312, 152);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(72, 85);
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(144, 152);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(72, 85);
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // lambLips
            // 
            this.lambLips.Location = new System.Drawing.Point(648, 400);
            this.lambLips.Name = "lambLips";
            this.lambLips.Size = new System.Drawing.Size(152, 32);
            this.lambLips.Step = 20;
            this.lambLips.TabIndex = 18;
            this.lambLips.MouseHover += new System.EventHandler(this.lambLips_MouseHover);
            // 
            // lambBack
            // 
            this.lambBack.Location = new System.Drawing.Point(480, 400);
            this.lambBack.Name = "lambBack";
            this.lambBack.Size = new System.Drawing.Size(152, 32);
            this.lambBack.Step = 20;
            this.lambBack.TabIndex = 17;
            this.lambBack.MouseHover += new System.EventHandler(this.lambBack_MouseHover);
            // 
            // lambBehind
            // 
            this.lambBehind.Location = new System.Drawing.Point(312, 400);
            this.lambBehind.Name = "lambBehind";
            this.lambBehind.Size = new System.Drawing.Size(152, 32);
            this.lambBehind.Step = 20;
            this.lambBehind.TabIndex = 16;
            this.lambBehind.MouseHover += new System.EventHandler(this.lambBehind_MouseHover);
            // 
            // lambFront
            // 
            this.lambFront.Location = new System.Drawing.Point(144, 400);
            this.lambFront.Name = "lambFront";
            this.lambFront.Size = new System.Drawing.Size(152, 32);
            this.lambFront.Step = 20;
            this.lambFront.TabIndex = 15;
            this.lambFront.MouseHover += new System.EventHandler(this.lambFront_MouseHover);
            // 
            // beefLips
            // 
            this.beefLips.Location = new System.Drawing.Point(648, 328);
            this.beefLips.Name = "beefLips";
            this.beefLips.Size = new System.Drawing.Size(152, 32);
            this.beefLips.Step = 20;
            this.beefLips.TabIndex = 14;
            this.beefLips.MouseHover += new System.EventHandler(this.beefLips_MouseHover);
            // 
            // beefBack
            // 
            this.beefBack.Location = new System.Drawing.Point(480, 328);
            this.beefBack.Name = "beefBack";
            this.beefBack.Size = new System.Drawing.Size(152, 32);
            this.beefBack.Step = 20;
            this.beefBack.TabIndex = 13;
            this.beefBack.MouseHover += new System.EventHandler(this.beefBack_MouseHover);
            // 
            // beefBehind
            // 
            this.beefBehind.Location = new System.Drawing.Point(312, 328);
            this.beefBehind.Name = "beefBehind";
            this.beefBehind.Size = new System.Drawing.Size(152, 32);
            this.beefBehind.Step = 20;
            this.beefBehind.TabIndex = 12;
            this.beefBehind.MouseHover += new System.EventHandler(this.beefBehind_MouseHover);
            // 
            // beefFront
            // 
            this.beefFront.Location = new System.Drawing.Point(144, 328);
            this.beefFront.Name = "beefFront";
            this.beefFront.Size = new System.Drawing.Size(152, 32);
            this.beefFront.Step = 20;
            this.beefFront.TabIndex = 11;
            
            this.beefFront.MouseHover += new System.EventHandler(this.beefFront_MouseHover);
            // 
            // porkLips
            // 
            this.porkLips.Location = new System.Drawing.Point(648, 256);
            this.porkLips.Name = "porkLips";
            this.porkLips.Size = new System.Drawing.Size(152, 32);
            this.porkLips.Step = 20;
            this.porkLips.TabIndex = 10;
            this.porkLips.MouseHover += new System.EventHandler(this.porkLips_MouseHover);
            // 
            // porkBack
            // 
            this.porkBack.Location = new System.Drawing.Point(480, 256);
            this.porkBack.Name = "porkBack";
            this.porkBack.Size = new System.Drawing.Size(152, 32);
            this.porkBack.Step = 20;
            this.porkBack.TabIndex = 9;
            this.porkBack.MouseHover += new System.EventHandler(this.porkBack_MouseHover);
            // 
            // porkBehind
            // 
            this.porkBehind.Location = new System.Drawing.Point(312, 256);
            this.porkBehind.Name = "porkBehind";
            this.porkBehind.Size = new System.Drawing.Size(152, 32);
            this.porkBehind.Step = 20;
            this.porkBehind.TabIndex = 8;
            this.porkBehind.MouseHover += new System.EventHandler(this.porkBehind_MouseHover);
            // 
            // porkFront
            // 
            this.porkFront.Location = new System.Drawing.Point(144, 256);
            this.porkFront.Name = "porkFront";
            this.porkFront.Size = new System.Drawing.Size(152, 32);
            this.porkFront.Step = 20;
            this.porkFront.TabIndex = 20;
            this.porkFront.MouseHover += new System.EventHandler(this.porkFront_MouseHover);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.Location = new System.Drawing.Point(40, 400);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(69, 25);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "양고기";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.Location = new System.Drawing.Point(40, 328);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(69, 25);
            this.metroLabel2.TabIndex = 5;
            this.metroLabel2.Text = "소고기";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.Location = new System.Drawing.Point(32, 256);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(88, 25);
            this.metroLabel1.TabIndex = 4;
            this.metroLabel1.Text = "돼지고기";
            // 
            // order
            // 
            this.order.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.order.Location = new System.Drawing.Point(624, 40);
            this.order.Name = "order";
            this.order.Size = new System.Drawing.Size(144, 48);
            this.order.TabIndex = 3;
            this.order.Text = "발주하기";
            this.order.UseSelectable = true;
            this.order.Click += new System.EventHandler(this.order_Click);
            // 
            // metroButton3
            // 
            this.metroButton3.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton3.Location = new System.Drawing.Point(432, 40);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(144, 48);
            this.metroButton3.TabIndex = 2;
            this.metroButton3.Text = "판매량";
            this.metroButton3.UseSelectable = true;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // add
            // 
            this.add.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.add.Location = new System.Drawing.Point(256, 40);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(144, 48);
            this.add.TabIndex = 1;
            this.add.Text = "도축하기";
            this.add.UseSelectable = true;
            this.add.Click += new System.EventHandler(this.add_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 545);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroProgressBar beefLips;
        private MetroFramework.Controls.MetroProgressBar beefBack;
        private MetroFramework.Controls.MetroProgressBar beefBehind;
        private MetroFramework.Controls.MetroProgressBar beefFront;
        private MetroFramework.Controls.MetroProgressBar porkLips;
        private MetroFramework.Controls.MetroProgressBar porkBack;
        private MetroFramework.Controls.MetroProgressBar porkBehind;
        private MetroFramework.Controls.MetroProgressBar porkFront;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton order;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroButton add;
        private MetroFramework.Controls.MetroProgressBar lambBehind;
        private MetroFramework.Controls.MetroProgressBar lambFront;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroProgressBar lambLips;
        private MetroFramework.Controls.MetroProgressBar lambBack;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.ToolTip toolTip4;
        private System.Windows.Forms.ToolTip toolTip5;
        private System.Windows.Forms.ToolTip toolTip6;
        private System.Windows.Forms.ToolTip toolTip7;
        private System.Windows.Forms.ToolTip toolTip8;
        private System.Windows.Forms.ToolTip toolTip9;
        private System.Windows.Forms.ToolTip toolTip10;
        private System.Windows.Forms.ToolTip toolTip11;
        private System.Windows.Forms.ToolTip toolTip12;
    }
}